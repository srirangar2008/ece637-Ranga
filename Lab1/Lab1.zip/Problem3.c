
#include <math.h>
#include "tiff.h"
#include "allocate.h"
#include "randlib.h"
#include "typeutil.h"
#include "defs.h"

void error(char*);
int8_t filterVal(struct TIFF_img* img, int row, int col);

int main(int argc, char** argv)
{
    FILE *fp;
    struct TIFF_img input_img, color_img;

    if ( argc != 2 ) error( argv[0] );

    /* open image file */
    if ( ( fp = fopen ( argv[1], "rb" ) ) == NULL ) {
        fprintf ( stderr, "cannot open file %s\n", argv[1] );
        exit ( 1 );
    }

    /* read image */
    if ( read_TIFF ( fp, &input_img ) ) {
        fprintf ( stderr, "error reading file %s\n", argv[1] );
        exit ( 1 );
    }

    /* close image file */
    fclose ( fp );
    //int32_t output_height = input_img.height + (2 * y_pad);
    //int32_t output_width = input_img.width + (2 * x_pad);
    get_TIFF ( &color_img, input_img.height, input_img.width, 'c' );
    printf("Input Height = %d, Input width = %d\n", input_img.height, input_img.width);

   double** filter = (double**)calloc(9,sizeof(double*));
   for(int i = 0; i < 9; i++)
   {
    filter[i] = (double*)calloc(9, sizeof(double));
   }

   for(int i = 0; i < 9; i++)
   {
    for(int j = 0; j < 9; j++)
    {
        filter[i][j] = 1.0/81;
    }
   }
   convolution2D(&input_img, &color_img, 9, 9, filter);
    
  if ( ( fp = fopen ( "color_output.tif", "wb" ) ) == NULL ) {
      fprintf ( stderr, "cannot open file color.tif\n");
      exit ( 1 );
  }
    
  /* write color image */
  if ( write_TIFF ( fp, &color_img ) ) {
      fprintf ( stderr, "error writing TIFF file %s\n", argv[2] );
      exit ( 1 );
  }

   fclose ( fp );

    free_TIFF ( &(input_img) );
    free_TIFF ( &(color_img) );
    
    return 0;
}

void error(char *name)
{
    printf("usage:  %s  image.tiff \n\n",name);
    printf("this program reads in a 24-bit color TIFF image.\n");
    printf("It then horizontally filters the green component, adds noise,\n");
    printf("and writes out the result as an 8-bit image\n");
    printf("with the name 'green.tiff'.\n");
    printf("It also generates an 8-bit color image,\n");
    printf("that swaps red and green components from the input image");
    exit(1);
}