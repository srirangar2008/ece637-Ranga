#include "defs.h"

// Convolution in 2D
// y[m,n] = 
// Sum(u)
// {
//     Sum(v)
//     {
//         h(u,v) * x(m-u, n-v)
//     }
// }

void convolution2D(struct TIFF_img* inputImg, struct TIFF_img* outputImg, int filterHeight, int filterWidth, 
                    double** filter)
{
    int fhIter = (filterHeight - 1)/2;
    int fwIter = (filterWidth - 1)/2;
    int imageHeight = inputImg->height;
    int imageWidth = inputImg->width;

    double red, green, blue;

    for(int i = 0; i < imageHeight; i++)
    {
        for(int j = 0; j < imageWidth; j++)
        {
            red = 0;
            green = 0;
            blue = 0;
            for(int row = -fhIter; row <= fhIter; row++)
            {
                for(int col = -fwIter; col <= fwIter; col++)
                {
                    int index_x = i - row;
                    int index_y = j - col;
                    if(index_x < imageHeight && index_y < imageWidth && index_x >= 0 && index_y >= 0)
                    {
                        red += filter[row + fhIter][col + fwIter] * inputImg->color[0][index_x][index_y];
                        green += filter[row + fhIter][col + fwIter] * inputImg->color[1][index_x][index_y];
                        blue += filter[row + fhIter][col + fwIter] * inputImg->color[2][index_x][index_y];
                    }
                }
            }
            outputImg->color[0][i][j] = limitPixel(red);
            outputImg->color[1][i][j] = limitPixel(green);
            outputImg->color[2][i][j] = limitPixel(blue);
        }
    } 
}

uint8_t limitPixel(double pixel)
{
    uint8_t colorVal;
    if(pixel > 255)
    {
        colorVal = 255;
    }
    else if(pixel < 0)
    {
        colorVal = 0;
    }
    else
    {
        colorVal = (uint8_t)pixel;
    }
    return colorVal;
}