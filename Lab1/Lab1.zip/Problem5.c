
#include <math.h>
#include "tiff.h"
#include "allocate.h"
#include "randlib.h"
#include "typeutil.h"
#include "defs.h"

void error(char*);
int8_t filterVal(struct TIFF_img* img, int row, int col);

int main(int argc, char** argv)
{
    FILE *fp;
    struct TIFF_img input_img, color_img;

    if ( argc != 2 ) error( argv[0] );

    /* open image file */
    if ( ( fp = fopen ( argv[1], "rb" ) ) == NULL ) {
        fprintf ( stderr, "cannot open file %s\n", argv[1] );
        exit ( 1 );
    }

    /* read image */
    if ( read_TIFF ( fp, &input_img ) ) {
        fprintf ( stderr, "error reading file %s\n", argv[1] );
        exit ( 1 );
    }

    /* close image file */
    fclose ( fp );
    get_TIFF ( &color_img, input_img.height, input_img.width, 'c' );

    double*** inter_img = (double***)calloc(3, sizeof(double**));
    for(int i = 0; i < 3; i++)
    {
        inter_img[i] = (double**)calloc(input_img.height, sizeof(double*));
        for(int j = 0; j < input_img.height; j++)
        {
            inter_img[i][j] = (double*)calloc(input_img.width, sizeof(double));
        }
    }
   for(int i = 0; i < input_img.height; i++)
   {
    for(int j = 0; j < input_img.width; j++)
    {
        inter_img[0][i][j] = 0.01 * input_img.color[0][i][j];
        inter_img[1][i][j] = 0.01 * input_img.color[1][i][j];
        inter_img[2][i][j] = 0.01 * input_img.color[2][i][j];
        
        if(i > 0)
        {
            inter_img[0][i][j]+= 0.9 * inter_img[0][i - 1][j];
            inter_img[1][i][j]+= 0.9 * inter_img[1][i - 1][j];
            inter_img[2][i][j]+= 0.9 * inter_img[2][i - 1][j];
        }
        if(j > 0)
        {
            inter_img[0][i][j]+= 0.9 * inter_img[0][i][j - 1];
            inter_img[1][i][j]+= 0.9 * inter_img[1][i][j - 1];
            inter_img[2][i][j]+= 0.9 * inter_img[2][i][j - 1];
        }
        if(i > 0 && j > 0)
        {
            inter_img[0][i][j] -= 0.81 * inter_img[0][i - 1][j - 1];
            inter_img[1][i][j] -= 0.81 * inter_img[1][i - 1][j - 1];
            inter_img[2][i][j] -= 0.81 * inter_img[2][i - 1][j - 1];
        }
    }

    for(int d = 0; d < 3; d++)
    {
        for(int i = 0; i < input_img.height; i++)
        {
            for(int j = 0; j < input_img.width; j++)
            {
                color_img.color[d][i][j] = limitPixel(inter_img[d][i][j]);
            }
        }
    }

    }
  if ( ( fp = fopen ( "color_IIR.tif", "wb" ) ) == NULL ) {
      fprintf ( stderr, "cannot open file color.tif\n");
      exit ( 1 );
  }
    
  /* write color image */
  if ( write_TIFF ( fp, &color_img ) ) {
      fprintf ( stderr, "error writing TIFF file %s\n", argv[2] );
      exit ( 1 );
  }

   fclose ( fp );

    free_TIFF ( &(input_img) );
    free_TIFF ( &(color_img) );
    
    return 0;
}

void error(char *name)
{
    printf("usage:  %s  image.tiff \n\n",name);
    printf("this program reads in a 24-bit color TIFF image.\n");
    printf("It then horizontally filters the green component, adds noise,\n");
    printf("and writes out the result as an 8-bit image\n");
    printf("with the name 'green.tiff'.\n");
    printf("It also generates an 8-bit color image,\n");
    printf("that swaps red and green components from the input image");
    exit(1);
}