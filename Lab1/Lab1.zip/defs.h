#ifndef DEFS_H
#define DEFS_H

#include "tiff.h"

void convolution2D(struct TIFF_img* inputImg, struct TIFF_img* outputImg, int filterHeight, int filterWidth, 
                    double** filter);
uint8_t limitPixel(double);

#endif
